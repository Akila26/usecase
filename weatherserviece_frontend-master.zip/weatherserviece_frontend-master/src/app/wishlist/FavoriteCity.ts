
export interface FavoriteCity {
    id?: number;
    userId: string;
    cityName: string;
  }
  