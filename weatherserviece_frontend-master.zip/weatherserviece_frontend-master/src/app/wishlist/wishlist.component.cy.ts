import { WishlistComponent } from './wishlist.component'

describe('WishlistComponent', () => {
  it('should mount', () => {
    cy.mount(WishlistComponent)
  })
})