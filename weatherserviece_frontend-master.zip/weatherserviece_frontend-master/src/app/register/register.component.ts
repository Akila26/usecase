import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../service/registration.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  constructor(private router: Router,private userRegistrationService:RegistrationService){}
  formData = {
    username: '',
    password: '',
    name: ''
  };

  register() {
    this.userRegistrationService.registerUser(this.formData).subscribe(
      (response) => {
        console.log('User registered successfully:', response);
        alert('Congratulations, registarting successfull!!')
        //location.reload();
        this.router.navigate(['/login']);
        // Optionally, perform additional actions after successful registration
      },
      (error) => {
        console.error('Registration error:', error);
        // Handle registration error
      }
    );
  }

  cancel() {
    // Implement cancel logic here
    console.log('Registration canceled');
    this.router.navigate(['/login'])

  }

}
