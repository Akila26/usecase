import { RegisterComponent } from './register.component'

describe('RegisterComponent', () => {
  it('should mount', () => {
    cy.mount(RegisterComponent)
  })
})