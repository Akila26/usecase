import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth_guard/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  constructor(private router: Router,private authService: AuthService){}

  signOut(): void {
   // this.authService.signOut();
    // Optionally, navigate to the login page or any other desired route
    //localStorage.removeItem('token');
    this.authService.logout();
    this.router.navigate(['/login']);
  }

}
