import { Component } from '@angular/core';
import { WeatherService } from '../service/weather.service';
import { WishlistService } from '../service/wishlist.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  selectedLocation: string = '';
  weatherData ={ 
    location: { name:'', region:'', country:'' }, 
    current: { temp_c:'' } 
}

  constructor(private weatherService: WeatherService,private wishlistService: WishlistService) {}

  getWeather() {
    if (this.selectedLocation) {
      this.weatherService.getWeather(this.selectedLocation).subscribe((data) => {
        this.weatherData = data.Payload;
        console.log("data",data)
        console.log("weatherData",this.weatherData)
      });
    }
  }
  userId:any;

  addToFavorites() {
    this.userId = localStorage.getItem('username');
    if (this.selectedLocation) {
      this.wishlistService.addFavoriteCity(this.userId, this.selectedLocation).subscribe(() => {
        console.log('City added to favorites:',this.selectedLocation);
        alert("successfully added to favorite ");
      });
    }else{
      alert("Alreadt present in the wishlist");
    }
  }

}
