import { AuthDirective } from './auth.directive';

describe('AuthDirective', () => {
  it('should create an instance', () => {
    const directive = new AuthDirective();
    expect(directive).toBeTruthy();
  });
});
