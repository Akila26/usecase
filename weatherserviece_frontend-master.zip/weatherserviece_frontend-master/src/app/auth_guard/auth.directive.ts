import { Directive } from '@angular/core';

@Directive({
  selector: '[appAuth]'
})
export class AuthDirective {

  constructor() { }

}
