import { FooterComponent } from './footer.component'

describe('FooterComponent', () => {
  it('should mount', () => {
    cy.mount(FooterComponent)
  })
})