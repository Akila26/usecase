import { CitydetailsComponent } from './citydetails.component'

describe('CitydetailsComponent', () => {
  it('should mount', () => {
    cy.mount(CitydetailsComponent)
  })
})