

describe('Login Page', () => {
    beforeEach(() => {
      cy.visit('/');
    });
  
    it('should display login form', () => {
      cy.get('app-login').should('exist');
      cy.get('mat-form-field').should('have.length', 2);
      cy.get('button[type="submit"]').should('exist').and('be.disabled');
    });
  
    it('should show error messages for invalid form submission', () => {
      cy.get('button[type="submit"]').click();
      cy.get('.mat-error').should('have.length', 2);
    });
  
    it('should allow user to fill out and submit the form', () => {
      const username = 'testuser';
      const password = 'testpassword';
  
      cy.get('input[formControlName="username"]').type(username);
      cy.get('input[formControlName="password"]').type(password);
  
      cy.get('button[type="submit"]').should('not.be.disabled').click();
  
      // Add more assertions based on your application behavior
      // For example, check that the user is redirected after a successful login
    });
  });
  